# Claude Usage Monitor (Chrome extension)

Tracks the usage limits of **several Claude accounts at once** and sends an alert before any of them runs out.

## Install (2 minutes)
1. Unzip this folder somewhere permanent (for example `Documents\claude-usage-monitor`).
2. Open `chrome://extensions`, then turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder.
4. Click **Details** on the extension and turn on **Allow in Incognito**. This is how you add extra accounts.
5. Pin the extension (puzzle icon → pin). The setup page opens by itself the first time.

## Add your accounts
| Account | How |
|---|---|
| Main (already signed in) | Settings → Accounts → **Detect signed-in sessions** → **Add** |
| Each extra account | Open an incognito window → sign in at claude.ai → **Detect** → **Add** → **close the incognito window** |
| In another browser or profile | claude.ai → F12 → Application → Cookies → copy `sessionKey` → **Add by session key** |

**Important:** don't click "Log out" in Claude for an account you're monitoring, because logging out invalidates its session. Close the incognito window instead. Before you sign in to the next account, close *all* incognito windows, since they share one set of cookies.

If an account shows "Session expired", sign in to it again (in incognito), then click **Detect** → **Update session**.

## What you get
- **Popup:** one card per account with bars for the 5-hour, weekly, weekly Opus, and weekly Sonnet limits. Each card shows reset countdowns, a "limit in ~X at this pace" projection, a "best account to use now" banner, session details (email, org, plan or tier, billing, masked key, capture source and date, session expiry, last check), and a copy-details button.
- **Alerts:** desktop notifications at the warning, critical, and 100% levels. Optional extras: pace alerts, repeat reminders, "available again" alerts on reset, a suggested alternative account, and session-expired alerts. Each alert has **Open Claude** and **Snooze 1 hour** buttons.
- **Sound:** four built-in tones with adjustable volume. **Quiet hours** can let critical alerts through.
- **Badge:** shows the highest usage, the lowest usage (best account), or the number of accounts above warning. Shows "!" on errors and "II" when paused.
- **Per account:** label, color, monitor on/off, alerts on/off, its own warning and critical thresholds, organization picker, and ordering.
- **Advanced:** check interval (1–120 min), request mode, history retention, export/import (session keys excluded unless you tick the box), debug log, and full reset.

## How it works
Every N minutes the background worker calls the same usage endpoint the claude.ai **Settings → Usage** page uses (`/api/organizations/{org}/usage`). For each account, a one-off network rule attaches that account's `sessionKey` to its request only. Your normal browsing session is never touched. Session keys stay in this browser's local extension storage and are only sent to claude.ai.

## Troubleshooting
- **"Blocked by claude.ai protection":** open any claude.ai tab and click refresh. If it keeps happening, set Advanced → Request mode → *Through an open claude.ai tab*.
- **Bars look wrong (e.g. 1% when it should be high):** Advanced → Usage value scale → *Fraction*.
- **No notifications:** make sure your OS allows notifications from Chrome (Windows: Settings → System → Notifications → Google Chrome).
- **Something else:** turn on debug logging under Advanced, click ⟳, then **Show log**.

Note: this relies on claude.ai's internal (undocumented) API. If Anthropic changes it, the extension shows a clear error instead of wrong numbers.
